﻿
/*kango.addMessageListener('post', function(event) {
	kango.console.log(event.data);
});
*/